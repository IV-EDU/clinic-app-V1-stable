# LAST PLAN – V1 UI, Branding & Arabic Roadmap

> Living roadmap for getting to a clean V1: unified UI, per‑clinic theming, and complete Arabic support, in focused, shippable feature slices.

This plan assumes the current codebase as it is today:
- `static/css/app.css` and `static/css/theme-system.css` already exist.
- Theme settings are stored via `clinic_app/services/theme_settings.py` and edited in **Admin → Theme**.
- Arabic/English and RTL are provided via `clinic_app/services/i18n.py` and `_base.html`.

Each phase should be focused on a single feature area (but can touch multiple files) and must not break existing flows.

---

## Guiding Principles
- **Single data root**: use top-level `data/` for DB/backups/exports. Treat `clinic_app/data/` as legacy/fixtures only.
- **Focused, safe slices**: each chunk targets one feature area (e.g. payments, expenses, appointments) and keeps the app usable at all times.
- **UI-first**: prefer template/CSS changes over Python logic. Change backend only for clear bugs or when wiring existing helpers or adding small, necessary fields.
- **Arabic/RTL first-class**: any new UI must work in both English and Arabic, with correct `dir` and font choices and safe wrapping.
- **Build on what exists**: reuse `render_page()`, `_base.html`, `theme_settings`, `i18n`, `doctor_colors`, `pdf_enhanced`, and existing services.
- **Always re-check work**: when backend logic or data structures change, run `Run-Tests.bat` or the relevant tests and fix failures before shipping.

---

## Phase 0 – Foundations & Safety (Ongoing)
- Confirm current behavior:
  - Run tests (`Run-Tests.bat`) and note any failing tests (do not fix unrelated failures yet).
  - Verify `render_page()` + `_base.html` are used for all core flows (dashboard, patients, payments, appointments, expenses, simple expenses).
  - Note exceptions (e.g. `diag_plus` standalone templates).
- Confirm theme plumbing:
  - Verify admin Theme tab saves `primary_color`, `accent_color`, `base_font_size`.
  - Confirm `render_page()` is injecting `theme_css` and that `theme-system.css` is loaded in `_base.html`.
- Data root check (no code changes unless needed):
  - Ensure new features read/write via `app.config["DATA_ROOT"]` and **not** `clinic_app/data/`.

Status: **Ongoing** – used as a sanity check before and after later phases.

---

## Phase A – Design System & Core Shell
Goal: establish a professional, consistent look for the login, patients “home” view, and patient header using shared cards/buttons/spacing.
Status: **Completed** – login, dashboard, and patient header now use the shared card/button system, with a consistent professional look.

- **Design system in CSS (`static/css/app.css`, `static/css/theme-system.css`)**
  - Define/confirm `.card` and `.u-card` as the main containers, with light backgrounds, subtle borders/shadows, and consistent padding.
  - Standardize buttons: `.btn`, `.btn.primary`, `.btn.secondary`, `.btn.danger`, `.btn.success`, using `--primary-color`, `--accent-color`, and other theme variables.
  - Add simple alert styles (success/warning/error/info) and spacing/typography helpers that work in both LTR and RTL.

- **Login page (`templates/auth/login.html`)**
  - Center the login card visually with a clear title and clean input layout.
  - Use the shared card and button styles; move ad‑hoc inline styles into CSS where reasonable.
  - Show bootstrap/first‑time hints as a proper alert, not raw text.

- **Core patients view (`templates/core/index.html`)**
  - Treat this as the “patients dashboard” for now:
    - Clean search bar card with primary/secondary buttons.
    - Stats card with patient count and today’s collected amount using the new design tokens.
    - Patient list card with a neat table: right‑aligned balances, consistent actions column.

- **Patient file header (`templates/patients/detail.html`)**
  - Refine the top patient summary card:
    - Clear grid for file number, name, phone, notes, balance.
    - Actions bar with diagnosis, edit, delete (and later payments‑related actions) using the standardized buttons.
  - Keep the payments list include (`payments/_list.html`) untouched in this phase.

Deliverable: the app feels like professional clinic software as soon as you log in and open the patients list/detail pages, with a shared visual language for cards and buttons.

---

## Phase B – Theme & Logo Engine
Goal: allow per‑clinic branding with a logo and safe, automatic theme colors that do not hurt the eyes.
Status: **Completed** – theme colors, base font size, logo upload, receipts branding, and Theme tab behavior are all wired and stable.

- **Logo storage & settings**
  - Extend `clinic_app/services/theme_settings.py` and `clinic_app/blueprints/admin_settings.py` to support uploading a clinic logo (stored under `data/`, e.g. `data/theme/logo.png`).
  - Update the Theme admin tab UI (`templates/admin/settings/index.html`) to include logo upload and preview, using shared card/button styles.

- **Header branding (`templates/_base.html`)**
  - Replace the “Clinic App” text in the header with the clinic logo when present, with a safe fallback to text when no logo is configured.
  - Ensure the header layout works in both English and Arabic.

- **Automatic colors from logo**
  - Add a “Pick colors from logo” action in the Theme admin UI.
  - Use an image helper (e.g. via `Pillow` or existing tooling) to extract 1–2 dominant colors from the logo.
  - Map them to `primary_color` / `accent_color` in a safe way:
    - Keep the overall background light.
    - Ensure text contrast is readable on buttons, chips, and cards.

- **Background behavior**
  - Use theme variables to implement subtle tinted or gradient backgrounds behind cards, while keeping main content on white/light surfaces for readability.

Deliverable: the app feels branded to the clinic (logo + colors) while remaining easy to read and not visually overwhelming.

---

## Phase C – Payments UI, Doctor Assignment & PDF Branding
Goal: redesign payment cards for clarity, require a doctor on new payments, and add logo/branding to receipts and PDFs.
Status: **Partially completed** – doctor is required and payment cards/doctor chips are implemented; PDF logo/branding is not wired yet.

- **Doctor on payments (backend + forms)**
  - Extend the payments data model to store `doctor_id` and `doctor_label` for each payment, using existing `Doctor` entries from `clinic_app/models.py`.
  - In the payment form (`templates/payments/form.html` + routes in `clinic_app/blueprints/payments/routes.py`):
    - Add a **required** doctor dropdown for new payments.
    - If validation fails, show a clear inline error and do not create the payment.
  - For existing payments:
    - Default missing doctor fields to the existing “Any doctor” entry configured in Admin → Doctor colors, so legacy data remains valid.

- **Payment card redesign (`templates/payments/_list.html`)**
  - Replace the current box‑heavy layout with one clean card per payment:
    - Top row: amount, date/time, doctor chip.
    - Middle: notes/description and payment method.
    - Bottom: actions (edit, delete, view/print receipt) using the standard button hierarchy.
  - Use spacing, typography, and a single card border/shadow instead of many nested boxes.
  - Ensure cards are easy to scan in both English and Arabic and do not overflow horizontally.

- **Doctor chips**
  - Show a pill‑shaped chip with the doctor’s name on each payment card.
  - Use the doctor’s configured color (via `doctor_colors`) as the chip background when available; otherwise a neutral chip that fits the theme.

- **PDF receipts & watermark (`clinic_app/services/pdf_enhanced.py`, `clinic_app/services/pdf.py`)**
  - If a logo is configured:
    - Use it in the PDF header and/or as a subtle watermark behind content.
    - Always resize large logos (e.g. 3000×3000) to a safe size and preserve aspect ratio.
  - Include doctor information on receipts where appropriate.

- **Testing & safety**
  - Run payments/receipts‑related tests (e.g. `tests/test_add_payment_route.py`, `tests/test_core_payments_list.py`, `tests/test_print_receipts.py`) after changes.

Deliverable: payments are visually clear and professional, every new payment is tied to a doctor, old data remains valid via “Any doctor”, and PDFs carry clinic branding safely.

---

## Phase D – Expenses (Legacy & Simple) UI Refresh
Goal: make both expenses flows look professional and consistent, without changing accounting behavior.
Status: **Completed (UI)** – legacy and simple expenses use the shared card/button styles with existing accounting logic unchanged.

- **Legacy expenses (`templates/expenses/`, `static/css/expenses.css`)**
  - Apply the shared card/button system to:
    - Main index, detail, status, categories, materials, suppliers.
  - Integrate the file‑upload flow (`templates/expenses/receipt_files.html`, `static/css/expense-file-upload.css`, `static/js/expense-file-upload.js`) into the new design so it feels like part of the same module.
  - Ensure all layouts behave correctly in Arabic/RTL and long labels wrap cleanly.

- **Simple expenses (`templates/simple_expenses/`, `static/css/simple-expenses.css`)**
  - Keep the minimal fields (date, total, description).
  - Apply the shared styles so the page feels modern and aligned with the rest of the app.

- **Testing**
  - Run `test_expense_system.py` and `test_simple_expenses.py` and fix any regressions caused by template/CSS changes.

Deliverable: expenses screens that are clean, readable, and visually integrated with the rest of the UI, with unchanged underlying logic.

---

## Phase E – Remaining UI: Appointments, Diag+, Reports, Admin
Goal: bring the remaining pages up to the design system standard while preserving existing workflows.
Status: **Partially completed** – appointments and the Theme tab are polished; Diag+, reports, and some admin screens still need final visual passes.

- **Appointments (`templates/appointments/vanilla.html`)**
  - Remove local/duplicate button styles where safe and switch to shared `.btn` variants and cards.
  - Ensure filters, patient chips, and action buttons use theme variables and look good in both languages.
  - Keep JSON script tags and data contracts unchanged unless updated deliberately in a separate, well‑scoped task.

- **Diag+ pages (`templates/diag_plus/diagnosis.html`, `medical.html`, `images.html`)**
  - Improve spacing, fonts, and card structures around the tooth charts and medical/image sections.
  - **Do not change tooth positions, numbering, or diagnosis mapping.** Only adjust presentation around them.

- **Reports (`templates/reports/collections.html`, `templates/reports/details.html`)**
  - Use the shared card/table styles so collections and details feel like part of the same product.

- **Admin settings (`templates/admin/settings/index.html`)**
  - Align users/roles/doctor colors/theme tabs with the design system (cards, buttons, alerts).

Deliverable: all major screens share one professional visual language without altering core medical or scheduling logic.

---

## Phase F – Analytics (After Core UI/Branding Are Solid)
Goal: provide useful, simple analytics based on the improved data model (especially doctor on payments).
Status: **Not started** – no dedicated analytics views have been added yet.

- **Per‑doctor collections**
  - Add analytics views (likely under `reports`) showing:
    - Collections per doctor over time.
    - Totals per period (day/week/month).
  - Use simple charts or clear tables, depending on what is easiest to maintain.

- **Other useful views**
  - High‑level summary of total collections, outstanding balances, and possibly procedure categories if available.

- **Safety & scope**
  - Build on the existing reports/DB; do not introduce new external infrastructure.
  - Keep analytics read‑only and focused on clarity.

Deliverable: an Analytics area that helps understand doctor performance and collections, built on top of the now consistent, branded UI.
