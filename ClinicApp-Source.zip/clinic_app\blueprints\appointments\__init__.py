from .routes import bp  # re-export for registration

__all__ = ["bp"]
