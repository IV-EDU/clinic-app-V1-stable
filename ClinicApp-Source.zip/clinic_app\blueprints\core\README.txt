Core feature module (patients, payments, reports) — routes will be migrated here without changing URLs.
