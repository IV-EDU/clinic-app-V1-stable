
from .core import bp  # re-export for registration
