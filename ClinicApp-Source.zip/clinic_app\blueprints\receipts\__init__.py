from .routes import bp  # re-export for registration
