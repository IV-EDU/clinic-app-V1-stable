Services: database/exports/audit/branding/licensing helpers will live here. No behavior changes.
