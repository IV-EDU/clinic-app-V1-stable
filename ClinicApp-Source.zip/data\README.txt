This folder will store the clinic database and files (created automatically on first run).
Backup = copy the whole data folder somewhere safe.
