DejaVu Sans Regular font is bundled for generating bilingual PDF receipts.

Source: `/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf` (DejaVu fonts project, Bitstream Vera derivative, license: https://dejavu-fonts.github.io/License.html).

The file `DejaVuSans.ttf` remains unchanged from the upstream release and is redistributed under the same terms (Bitstream Vera License + Public Domain contributions).
